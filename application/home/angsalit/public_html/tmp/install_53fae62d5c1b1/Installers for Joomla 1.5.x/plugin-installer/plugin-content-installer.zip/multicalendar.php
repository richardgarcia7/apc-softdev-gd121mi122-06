<?php
/**
 * @version		$Id: example.php 14401 2010-01-26 14:10:00Z louis $
 * @package		Joomla
 * @subpackage	Content
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
require_once( JPATH_SITE.'/components/com_multicalendar/DC_MultiViewCal/php/list.inc.php' );

/**
 * Multi Calendar Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */

function MultiCalendar_replacer( &$matches ) {
    global $arrayJS_list,$zscripts;
    $mainframe  =& JFactory::getApplication();
    $id = (int)$matches[1];
    $container = "plg".mt_rand();
    $language = $mainframe->getCfg('language');
    $style = $matches[5];
    $views = "";
    $buttons = "";
    $edition = $matches[6];
    $sample = "";
    $otherparamsvalue = $matches[15];
    $palette = intval($matches[14]);
    $viewdefault = $matches[3];
    $numberOfMonths = $matches[8];
    $start_weekday = $matches[4];
    $msg = print_scripts($id,$container,$language,$style,$views,$buttons,$edition,$sample,$otherparamsvalue,$palette,$viewdefault,$numberOfMonths,$start_weekday,true,$matches);
    if ($msg=="")
        return print_html($container);
    else
        return $msg;
}
class plgContentMulticalendar extends JPlugin
{

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentMulticalendar( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	/**
	 * Example prepare content method
	 *
	 * Method is called by the view
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 */
	function onPrepareContent( &$article, &$params, $limitstart )
	{
		global $mainframe;


		// define the regular expression for the bot
		$regex = "#\{multicalendar\:(.*?)\:(\d{4})\:(.*?)\:(\d{1})\:(.*?)\:(\d{1})\:(\d{3})\:(\d{1,2})\:(\d{1})\:(.*?)\:(\d{1})\:(.*?)\:(.*?):(.*?):(.*?)\}#s";
		$article->text = preg_replace_callback( $regex, 'MultiCalendar_replacer', $article->text );
		return true;
	}
}