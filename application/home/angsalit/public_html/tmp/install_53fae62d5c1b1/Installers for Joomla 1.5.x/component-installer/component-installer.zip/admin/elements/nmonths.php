<?php
/**
* @version		$Id: nmonths.php 14401 2010-01-26 14:10:00Z louis $
* @package		Joomla.Framework
* @subpackage	Parameter
* @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

/**
 * Renders a nmonths element
 *
 * @package 	Joomla.Framework
 * @subpackage		Parameter
 * @since		1.5
 */

class JElementNMonths extends JElement
{
	/**
	* Element name
	*
	* @access	protected
	* @var		string
	*/
	var	$_name = 'NMonths';
    protected $forceMultiple = true; 
	function fetchElement($name, $value, &$node, $control_name)
	{

	    //return JHTML::_('select.genericlist',   "gtree", "ctrl", "attribs", 'value', 'text', $value, $control_name.$name );
	    $value = str_replace("-!-amp-!-","&",$value);
	    $value = explode(",",$value);    
	    
	    
		if ((string) $value[0]!='1')
		    array_splice ($value, 0, 0, "0");
		if ((string) $value[2]!='1')
		    array_splice ($value, 2, 0, "0");

		$checked1	= ((string) $value[0]=='1') ? ' checked' : '';
		$checked2	= ((string) $value[2]=='1') ? ' checked' : '';
		$selected1	= ((string) $value[1]=='mouseover') ? ' selected="true"' : '';
		$selected2	= ((string) $value[1]=='click') ? ' selected="true"' : '';
		$selected3	= ((string) $value[4]=='new_window') ? ' selected="true"' : '';
		$selected4	= ((string) $value[4]=='same_window') ? ' selected="true"' : '';
		
		$value[3] = str_replace("-!-comma-!-",",",$value[3]);
		
		
        $html = array();
        

		$html[] = '<script type="text/javascript">function updatelist_'.$name.'(){'.
		           'var k = document.getElementById("'.$control_name.$name.'");'.
		           'var v;'.
		           'k.value="";'.		           
		           'v=document.getElementById("'.$name.'0"); if(v.checked) { if(k.value!="")k.value +=","; k.value +=v.value; }'.
		           'v=document.getElementById("'.$name.'1"); if(k.value!="")k.value +=","; k.value +=v.options[v.selectedIndex].value; '.
		           'v=document.getElementById("'.$name.'2"); if(v.checked) { if(k.value!="")k.value +=","; k.value +=v.value; }'.
		           'v=document.getElementById("'.$name.'3"); if(k.value!="")k.value +=","; k.value +=jcproccess(v.value); '.
		           'v=document.getElementById("'.$name.'4"); if(k.value!="")k.value +=","; k.value +=v.options[v.selectedIndex].value; '.
		          '}'.
		          'function jcproccess(str) { str = str.replace(",","-!-comma-!-"); str = str.replace("&","-!-amp-!-"); return str; } '.
		          '</script>';
		$html[] = '<input type="hidden"  id="'.$control_name.$name.'" name="'.$control_name.'['.$name.']" value="'.$value.'" />';
		        
        
        $html[] = '<script>function showhide(id){'.
                  'updatelist_'.$name.'();'.
                  'var obj1 = document.getElementById(id+"0");'.
                  'var obj2 = document.getElementById(id+"1");'. 
                  'var obj3 = document.getElementById(id+"div");'.
                  'if ((obj1.checked) && (obj2.selectedIndex==1))'.
                  '    obj3.style.display = "none";'.
                  'else    '.
                  '    obj3.style.display = "";'.
                  '}</script>';
		$html[] = '<div><input type="checkbox" name="'.$name.'0" id="'.$name.'0"' .
				' value="1" '.$checked1.' onclick="javascript:showhide(\''.$name.'\')"/><span style="float:left;display:inline;padding:5px 5px 0px 0px">'.JText::_( 'SHOW TOOLTIP ON' ).'</span>' .
				'<select name="'.$name.'1" id="'.$name.'1" onchange="javascript:showhide(\''.$name.'\')"><option value="mouseover" '.$selected1.' >'.JText::_( 'MOUSE OVER' ).'</option><option value="click" '.$selected2.'>'.JText::_( 'CLICK' ).'</option></select>' .
				'</div><label id="jform_params_sample-lbl" class="hasTip">&nbsp;</label><div id="'.$name.'div"><input onclick="updatelist_'.$name.'();" type="checkbox" name="'.$name.'2" id="'.$name.'2"' .
				' value="1" '.$checked2.'/><span style="float:left;display:inline;padding:5px 5px 0px 0px">'.JText::_( 'GO TO THE URL' ).'</span><input onblur="updatelist_'.$name.'();" type="text" name="'.$name.'3" id="'.$name.'3"' .
				' value="'.htmlspecialchars($value[3], ENT_COMPAT, 'UTF-8').'"/><label id="jform_params_sample-lbl" class="hasTip">&nbsp;</label><span style="float:left;display:inline;padding:5px 5px 0px 20px">'.JText::_( 'IN' ).'</span>'.
				'<select onchange="updatelist_'.$name.'();" name="'.$name.'4" id="'.$name.'4"><option value="new_window" '.$selected3.' >'.JText::_( 'NEW WINDOW' ).'</option><option value="same_window" '.$selected4.'>'.JText::_( 'SAME WINDOW' ).'</option></select>' .
				'</div>';
		$html[] = '<script>showhide(\''.$name.'\')</script>';
		$html[] = '';

		return implode($html);		
	}	
	
}
