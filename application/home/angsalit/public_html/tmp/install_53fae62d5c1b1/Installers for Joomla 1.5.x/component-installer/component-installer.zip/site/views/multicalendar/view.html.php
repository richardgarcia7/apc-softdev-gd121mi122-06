<?php
/**
* @Copyright Copyright (C) 2010 CodePeople, www.codepeople.net
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*
* This file is part of Multi Calendar for Joomla <www.joomlacalendars.com>.
* 
* Multi Calendar for Joomla is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Multi Calendar for Joomla  is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Multi Calendar for Joomla.  If not, see <http://www.gnu.org/licenses/>.
*
**/

defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class multicalendarViewmulticalendar extends JView
{
	function display($tpl = null)
	{
	    $task = JRequest::getVar( 'task' );
		if ($task=="load"){
			$tpl = "load";
			parent::display($tpl);
		}
		else if ($task=="editevent"){
			$tpl = "editevent";
			parent::display($tpl);
		}
		else
		{
		    $mainframe = JFactory::getApplication();
		
		    $document =& JFactory::getDocument();
		    $db 	  =& JFactory::getDBO();
		    $document =& JFactory::getDocument();
		    $pathway  =& $mainframe->getPathway();
		    
		    /**
		     * Get the calendar ID from the URI to use it in the view
		     */
		    $multicalendar_id = JRequest::getVar( 'id', 0, '', 'int' );
		    
		    /**
		     * Load the calendar details using the model
		     */
		    $multicalendar =& JTable::getInstance('multicalendar', 'Table');
		    $multicalendar->load( $multicalendar_id );
            
		    /**
		     * Fetch the parameters from the menu and the core configuration
		     */
		    $params =& $mainframe->getParams('com_multicalendar');
            
		    $menus	= &JSite::getMenu();
		    $menu	= $menus->getActive();
		    $mparams = new JParameter( $menu->params );
		    
		    $params->merge($mparams);		    
		    $params->set('multicalendar_id',	$multicalendar_id);
		    
		    
		    /**
		     * Set page title information
		     * because the application sets a default page title, we need to get it
		     * right from the menu item itself
		     */
		    if (is_object( $menu )) {
		    	$menu_params = new JParameter( $menu->params );
		    	if (!$menu_params->get( 'page_title')) {
		    		$params->set('page_title',	$multicalendar->title);
		    	}
		    } else {
		    	$params->set('page_title',	$multicalendar->title);
		    }
		    $document->setTitle( $params->get( 'page_title' ) );
            
		    
		    
		    /**
		     * Assign the information to the view object
		     */
		    $this->assignRef('params',	$params);
		    $this->assignRef('multicalendar',	$multicalendar);
		    
		    parent::display($tpl);
		}    
	}
}
?>