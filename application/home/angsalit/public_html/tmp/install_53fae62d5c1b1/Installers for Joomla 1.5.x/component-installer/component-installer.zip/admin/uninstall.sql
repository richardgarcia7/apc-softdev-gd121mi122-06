DROP TABLE IF EXISTS `#__dc_mv_calendars`;
DROP TABLE IF EXISTS `#__dc_mv_events`;
DROP TABLE IF EXISTS `#__dc_mv_free`;
DROP TABLE IF EXISTS `#__dc_mv_configuration`;