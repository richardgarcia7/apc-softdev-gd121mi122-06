<?php
defined('_JEXEC') or die( 'Restricted access' );
class JElementPalettes extends JElement
{
	
	var	$_name = 'Palettes'; 
	function fetchElement($name, $value, &$node, $control_name)
	{
		$db =& JFactory::getDBO();

		$db->setQuery("select palettes from #__dc_mv_configuration where id=1");

		$rows = $db->loadObjectList();
		$rows = unserialize($rows[0]->palettes);
		$options = array();
		for ($i=0;$i<count($rows);$i++)
		{
		    $options[] = JHtml::_('select.option', $i, JText::_($rows[$i]["name"]), 'id', 'title');
		}
		return JHTML::_('select.genericlist',  $options, ''.$control_name.'['.$name.']', 'class="inputbox"', 'id', 'title', $value, $control_name.$name );
	}
}
