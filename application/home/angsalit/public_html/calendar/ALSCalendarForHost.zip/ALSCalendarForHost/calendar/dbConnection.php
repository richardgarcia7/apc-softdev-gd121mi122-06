<?php 

//for hosting  

    $servername = "localhost";
    $username = "asnd_lcmam";
    $password = "asnd_lcmam";
    $dbname = "asnd_lcmam";

//*/

/*for testing 

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "asnd_lcmam";

*/

?>