<?php 

/*/for testing  /*

    $day="01";
    $month="01";
    $year="2015";

// */

//for development
error_reporting(E_ERROR);
    $day="01";
    $month="01";
    $year=date('Y');
    $yearAgo = date('Y', strtotime('1 year ago'));
    $year=$yearAgo;
    

//

?>